
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import os
import shutil
from datetime import datetime

# --- 应用配置 ---
app = Flask(__name__, template_folder='./templates', static_folder='static')
app.jinja_env.globals.update(datetime=datetime)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'dev_default_secret_key_!@#$%^&*()')

# --- 数据库设置 ---
DB_PATH = 'instance/students.db'

# --- 数据库初始化函数 (init_db) ---
def init_db():
    instance_dir = os.path.dirname(DB_PATH)
    if not os.path.exists(instance_dir): os.makedirs(instance_dir)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS students (id TEXT PRIMARY KEY, name TEXT NOT NULL, gender TEXT, age INTEGER, class TEXT, math_score REAL, english_score REAL, chinese_score REAL, physics_score REAL, chemistry_score REAL, total_score REAL, average_score REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT DEFAULT 'teacher', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS system_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, action TEXT NOT NULL, details TEXT, ip_address TEXT, user_agent TEXT, timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    c.execute("SELECT id FROM users WHERE username = ?", ('admin',))
    if c.fetchone() is None:
        try:
            hashed_pw = generate_password_hash('admin123')
            c.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", ('admin', hashed_pw, 'admin'))
            print("默认管理员用户 'admin' 已创建 (密码: admin123)。")
        except sqlite3.IntegrityError: print("默认管理员用户已存在或发生其他错误。")
    conn.commit()
    conn.close()

# --- 获取数据库连接函数 (get_db_connection) ---
def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# --- 辅助函数 (calculate_scores, log_action, get_user) ---
def calculate_scores(scores_dict):
    valid_scores = [score for score in scores_dict.values() if isinstance(score, (int, float))]
    total = sum(valid_scores)
    average = total / len(valid_scores) if valid_scores else 0
    return total, round(average, 2)

def log_action(action, details=None):
    if 'username' not in session: return
    conn = None
    try:
        conn = get_db_connection()
        conn.execute('''INSERT INTO system_logs (username, action, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)''',
                     (session.get('username'), action, details, request.remote_addr, request.user_agent.string))
        conn.commit()
    except Exception as e: print(f"记录操作日志时出错: {e}")
    finally:
        if conn: conn.close()

def get_user(username):
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    conn.close()
    return user

# --- 装饰器 (login_required, admin_required) ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            flash('请先登录!', 'warning')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if session.get('role') != 'admin':
            flash('需要管理员权限!', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

# --- 上下文处理器，用于向所有模板注入 current_bs_theme ---
@app.context_processor
def inject_current_bs_theme():
    # 从 session 中获取当前选择的导航栏/整体主题
    selected_theme = session.get('navbar_theme', 'green') # 默认 'green'

    # 判断这个主题应该对应 Bootstrap 的 'light' 还是 'dark' 模式
    # 假设 'dark' 主题是真正的暗色模式，其他自定义主题（如 'yuan', 'green', 'blue'）是浅色模式的变体
    if selected_theme == 'dark':
        current_bs_theme = 'dark'
    else:
        current_bs_theme = 'light'
    return dict(current_bs_theme=current_bs_theme)


# --- 路由 ---

@app.route('/')
@login_required
def index():
    sort_by = request.args.get('sort_by', 'created_at')
    sort_order = request.args.get('sort_order', 'DESC')
    valid_columns = ['id', 'name', 'age', 'class', 'total_score', 'average_score', 'created_at']
    if sort_by not in valid_columns: sort_by = 'created_at'
    if sort_order.upper() not in ['ASC', 'DESC']: sort_order = 'DESC'
    conn = get_db_connection()
    try:
        query = f"SELECT * FROM students ORDER BY {sort_by} {sort_order.upper()}"
        students = conn.execute(query).fetchall()
    except sqlite3.Error as e:
        flash(f"获取学生列表时出错: {e}", "danger")
        students = []
    finally: conn.close()
    return render_template('index.html', students=students, sort_by=sort_by, sort_order=sort_order.lower())

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']; password = request.form['password']
        user = get_user(username)
        if user and check_password_hash(user['password'], password):
            session['username'] = user['username']; session['role'] = user['role']
            # 登录时，如果用户之前没有设置过主题，则默认为 'green'
            session['navbar_theme'] = session.get('navbar_theme', 'green')
            log_action('用户登录'); flash('登录成功!', 'success')
            next_page = request.args.get('next') or url_for('index'); return redirect(next_page)
        else: flash('用户名或密码错误!', 'danger')
    if 'username' in session: return redirect(url_for('index'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    log_action('用户登出');
    # 保留主题偏好，或者根据需求决定是否清除
    # current_theme = session.get('navbar_theme')
    session.clear();
    # if current_theme: session['navbar_theme'] = current_theme # 如果希望登出后下次默认还是这个主题
    flash('您已成功登出', 'success');
    return redirect(url_for('login'))

@app.route('/add', methods=['GET', 'POST'])
@login_required
def add():
    if request.method == 'POST':
        def get_form_value(key, type_converter=str, default=None):
            value = request.form.get(key, '').strip()
            if not value: return default if not (type_converter in (int, float) and default is None) else ''
            try: return type_converter(value)
            except (ValueError, TypeError): flash(f'提供的 "{key}" 值 ({request.form.get(key)}) 无效。', 'danger'); return None
        student_data = { 'id': get_form_value('id'), 'name': get_form_value('name'), 'gender': get_form_value('gender'), 'age': get_form_value('age', int), 'class': get_form_value('class'), 'math_score': get_form_value('math_score', float, default=None), 'english_score': get_form_value('english_score', float, default=None), 'chinese_score': get_form_value('chinese_score', float, default=None), 'physics_score': get_form_value('physics_score', float, default=None), 'chemistry_score': get_form_value('chemistry_score', float, default=None) }
        required_fields = ['id', 'name', 'gender', 'age']
        missing_required = [k for k in required_fields if not student_data[k] and student_data[k] != 0]
        if missing_required: flash(f"{', '.join(missing_required)} 是必填项。", 'danger'); return render_template('add.html', student=request.form)
        conversion_errors = [k for k, v in student_data.items() if v is None and request.form.get(k)];
        if conversion_errors: return render_template('add.html', student=request.form)
        if student_data['age'] is not None and not (10 <= student_data['age'] <= 30): flash('年龄必须在 10 到 30 之间。', 'danger'); return render_template('add.html', student=request.form)
        scores = {k: student_data[k] for k in ['math_score', 'english_score', 'chinese_score', 'physics_score', 'chemistry_score']}; total_score, average_score = calculate_scores({k: v for k, v in scores.items() if v is not None})
        for key in scores.keys():
            if student_data[key] == '': student_data[key] = None
        conn = get_db_connection()
        try:
            conn.execute('''INSERT INTO students (id, name, gender, age, class, math_score, english_score, chinese_score, physics_score, chemistry_score, total_score, average_score) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (student_data['id'], student_data['name'], student_data['gender'], student_data['age'], student_data['class'], student_data['math_score'], student_data['english_score'], student_data['chinese_score'], student_data['physics_score'], student_data['chemistry_score'], total_score, average_score))
            conn.commit(); log_action('添加学生', f"学号: {student_data['id']}"); flash('学生信息添加成功!', 'success'); return redirect(url_for('index'))
        except sqlite3.IntegrityError: flash('该学号已存在!', 'danger'); conn.rollback()
        except Exception as e: flash(f'添加学生时发生错误: {e}', 'danger'); conn.rollback()
        finally: conn.close()
        return render_template('add.html', student=request.form)
    return render_template('add.html', student={})

@app.route('/edit/<string:id>', methods=['GET', 'POST'])
@login_required
def edit(id):
    conn_get = get_db_connection(); student = conn_get.execute("SELECT * FROM students WHERE id = ?", (id,)).fetchone(); conn_get.close()
    if not student: flash('未找到该学生!', 'danger'); return redirect(url_for('index'))
    if request.method == 'POST':
        def get_form_value(key, type_converter=str, default=None):
             value = request.form.get(key, '').strip();
             if not value: return default if not (type_converter in (int, float) and default is None) else ''
             try: return type_converter(value)
             except (ValueError, TypeError): flash(f'提供的 "{key}" 值 ({request.form.get(key)}) 无效。', 'danger'); return None
        student_data = { 'name': get_form_value('name'), 'gender': get_form_value('gender'), 'age': get_form_value('age', int), 'class': get_form_value('class'), 'math_score': get_form_value('math_score', float, default=None), 'english_score': get_form_value('english_score', float, default=None), 'chinese_score': get_form_value('chinese_score', float, default=None), 'physics_score': get_form_value('physics_score', float, default=None), 'chemistry_score': get_form_value('chemistry_score', float, default=None) }
        required_fields = ['name', 'gender', 'age']; missing_required = [k for k in required_fields if not student_data[k] and student_data[k] != 0]
        current_data_for_rerender = dict(student); current_data_for_rerender.update(request.form)
        if missing_required: flash(f"{', '.join(missing_required)} 是必填项。", 'danger'); return render_template('edit.html', student=current_data_for_rerender)
        conversion_errors = [k for k, v in student_data.items() if v is None and request.form.get(k)]
        if conversion_errors: return render_template('edit.html', student=current_data_for_rerender)
        if student_data['age'] is not None and not (10 <= student_data['age'] <= 30): flash('年龄必须在 10 到 30 之间。', 'danger'); return render_template('edit.html', student=current_data_for_rerender)
        scores = {k: student_data[k] for k in ['math_score', 'english_score', 'chinese_score', 'physics_score', 'chemistry_score']}; total_score, average_score = calculate_scores({k: v for k, v in scores.items() if v is not None and v != ''})
        for key in scores.keys():
            if student_data[key] == '': student_data[key] = None
        conn_update = get_db_connection()
        try:
            conn_update.execute('''UPDATE students SET name=?, gender=?, age=?, class=?, math_score=?, english_score=?, chinese_score=?, physics_score=?, chemistry_score=?, total_score=?, average_score=? WHERE id=?''', (student_data['name'], student_data['gender'], student_data['age'], student_data['class'], student_data['math_score'], student_data['english_score'], student_data['chinese_score'], student_data['physics_score'], student_data['chemistry_score'], total_score, average_score, id))
            conn_update.commit(); log_action('修改学生信息', f"学号: {id}"); flash('学生信息更新成功!', 'success'); return redirect(url_for('index'))
        except Exception as e: flash(f'更新学生信息时出错: {e}', 'danger'); conn_update.rollback()
        finally: conn_update.close()
        return render_template('edit.html', student=current_data_for_rerender)
    return render_template('edit.html', student=student)

@app.route('/delete/<string:id>')
@login_required
def delete(id):
    conn = get_db_connection()
    try:
        student_exists = conn.execute("SELECT id FROM students WHERE id = ?", (id,)).fetchone()
        if student_exists: conn.execute("DELETE FROM students WHERE id = ?", (id,)); conn.commit(); log_action('删除学生', f"学号: {id}"); flash('学生信息删除成功!', 'success')
        else: flash('未找到要删除的学生!', 'warning')
    except Exception as e: flash(f'删除学生时出错: {e}', 'danger'); conn.rollback()
    finally: conn.close()
    return redirect(url_for('index'))

@app.route('/search', methods=['GET', 'POST'])
@login_required
def search():
    students = []
    keyword = request.form.get('keyword', '').strip() if request.method == 'POST' else request.args.get('keyword', '').strip()
    if keyword:
        conn = get_db_connection(); search_term = f'%{keyword}%'
        try:
            students = conn.execute('''SELECT * FROM students WHERE id LIKE ? OR name LIKE ? OR class LIKE ? ORDER BY created_at DESC''', (search_term, search_term, search_term)).fetchall()
            log_action('搜索学生', f"关键词: {keyword}")
            if request.method == 'POST': flash(f'找到 {len(students)} 条关于 "{keyword}" 的记录。' if students else f'未找到关于 "{keyword}" 的记录。', 'info')
        except Exception as e: flash(f"搜索时出错: {e}", "danger")
        finally: conn.close()
    elif request.method == 'POST': flash('请输入搜索关键词。', 'warning')
    return render_template('search.html', students=students, keyword=keyword)

@app.route('/stats')
@login_required
def stats():
    conn = get_db_connection(); stats_data = { 'total_students': 0, 'avg_total': 0, 'avg_math': 0, 'avg_english': 0, 'avg_chinese': 0, 'avg_physics': 0, 'avg_chemistry': 0, 'class_stats': [], 'score_distribution': None }
    try:
        stats_data['total_students'] = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0] or 0
        if stats_data['total_students'] > 0:
            stats_data['avg_total'] = conn.execute("SELECT COALESCE(AVG(total_score), 0) FROM students").fetchone()[0]; stats_data['avg_math'] = conn.execute("SELECT COALESCE(AVG(math_score), 0) FROM students").fetchone()[0]; stats_data['avg_english'] = conn.execute("SELECT COALESCE(AVG(english_score), 0) FROM students").fetchone()[0]; stats_data['avg_chinese'] = conn.execute("SELECT COALESCE(AVG(chinese_score), 0) FROM students").fetchone()[0]; stats_data['avg_physics'] = conn.execute("SELECT COALESCE(AVG(physics_score), 0) FROM students").fetchone()[0]; stats_data['avg_chemistry'] = conn.execute("SELECT COALESCE(AVG(chemistry_score), 0) FROM students").fetchone()[0]
            stats_data['class_stats'] = conn.execute('''SELECT class, COUNT(*) as count, COALESCE(AVG(total_score), 0) as avg_total, COALESCE(AVG(math_score), 0) as avg_math, COALESCE(AVG(english_score), 0) as avg_english, COALESCE(AVG(chinese_score), 0) as avg_chinese FROM students GROUP BY class ORDER BY class''').fetchall()
            stats_data['score_distribution'] = conn.execute('''SELECT SUM(CASE WHEN average_score >= 90 THEN 1 ELSE 0 END) as excellent, SUM(CASE WHEN average_score >= 80 AND average_score < 90 THEN 1 ELSE 0 END) as good, SUM(CASE WHEN average_score >= 70 AND average_score < 80 THEN 1 ELSE 0 END) as medium, SUM(CASE WHEN average_score >= 60 AND average_score < 70 THEN 1 ELSE 0 END) as pass, SUM(CASE WHEN average_score < 60 THEN 1 ELSE 0 END) as fail FROM students''').fetchone()
        log_action('查看统计信息')
    except Exception as e: flash(f"加载统计数据时出错: {e}", "danger")
    finally: conn.close()
    for key in ['avg_total', 'avg_math', 'avg_english', 'avg_chinese', 'avg_physics', 'avg_chemistry']: stats_data[key] = round(stats_data[key], 2)
    return render_template('stats.html', **stats_data)

@app.route('/change_password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current_password = request.form['current_password']; new_password = request.form['new_password']; confirm_password = request.form['confirm_password']
        if not all([current_password, new_password, confirm_password]): flash('所有字段均为必填项!', 'warning'); return redirect(url_for('change_password'))
        if len(new_password) < 6: flash('新密码长度至少为6个字符!', 'warning'); return redirect(url_for('change_password'))
        if new_password != confirm_password: flash('新密码与确认密码不匹配!', 'warning'); return redirect(url_for('change_password'))
        conn = get_db_connection(); user = conn.execute("SELECT * FROM users WHERE username = ?", (session['username'],)).fetchone()
        if not user or not check_password_hash(user['password'], current_password): flash('当前密码不正确!', 'danger'); conn.close(); return redirect(url_for('change_password'))
        try:
            hashed_pw = generate_password_hash(new_password); conn.execute("UPDATE users SET password = ? WHERE username = ?", (hashed_pw, session['username'])); conn.commit()
            log_action('修改密码'); flash('密码修改成功!', 'success'); return redirect(url_for('index'))
        except Exception as e: flash(f'修改密码时出错: {e}', 'danger'); conn.rollback()
        finally: conn.close()
        return redirect(url_for('change_password'))
    return render_template('change_password.html')

# --- 管理员路由 ---
@app.route('/system_log')
@admin_required
def system_log():
    username = request.args.get('username', '').strip(); action = request.args.get('action', '').strip()
    start_date = request.args.get('start_date', '').strip(); end_date = request.args.get('end_date', '').strip()
    conn = get_db_connection(); query = "SELECT * FROM system_logs WHERE 1=1"; params = []
    if username: query += " AND username LIKE ?"; params.append(f'%{username}%')
    if action: query += " AND action LIKE ?"; params.append(f'%{action}%')
    if start_date: query += " AND DATE(timestamp) >= ?"; params.append(start_date)
    if end_date: query += " AND DATE(timestamp) <= ?"; params.append(end_date)
    query += " ORDER BY timestamp DESC LIMIT 200"
    try: logs = conn.execute(query, tuple(params)).fetchall()
    except Exception as e: logs = []; flash(f"查询日志时出错: {e}", "danger")
    finally: conn.close()
    filters = {'username': username, 'action': action, 'start_date': start_date, 'end_date': end_date}
    return render_template('system_log.html', logs=logs, filters=filters)

@app.route('/backup_db')
@admin_required
def backup_db():
    backup_dir = 'backups'; os.makedirs(backup_dir, exist_ok=True); timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_filename = f"students_backup_{timestamp}.db"; backup_path = os.path.join(backup_dir, backup_filename)
    try: shutil.copy2(DB_PATH, backup_path); log_action('数据库备份', f"备份文件: {backup_filename}"); flash(f'数据库备份成功! 文件: {backup_filename}', 'success')
    except Exception as e: flash(f'数据库备份失败: {e}', 'danger'); print(f"备份数据库时出错: {e}")
    return redirect(url_for('system_log'))

@app.route('/manage_users')
@admin_required
def manage_users():
    conn = get_db_connection(); users = conn.execute("SELECT id, username, role, created_at FROM users ORDER BY created_at DESC").fetchall(); conn.close()
    return render_template('manage_users.html', users=users)

@app.route('/add_user', methods=['GET', 'POST'])
@admin_required
def add_user():
    if request.method == 'POST':
        username = request.form.get('username', '').strip(); password = request.form.get('password', ''); role = request.form.get('role', '').strip()
        if not all([username, password, role]): flash('用户名、密码和角色均为必填项!', 'warning'); return render_template('add_user.html', username=username, role=role)
        if len(password) < 6: flash('密码长度至少为6个字符!', 'warning'); return render_template('add_user.html', username=username, role=role)
        if role not in ['admin', 'teacher']: flash('无效的角色!', 'danger'); return render_template('add_user.html', username=username, role=role)
        hashed_pw = generate_password_hash(password); conn = get_db_connection()
        try:
            conn.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", (username, hashed_pw, role)); conn.commit()
            log_action('添加用户', f"用户名: {username}, 角色: {role}"); flash('用户添加成功!', 'success'); return redirect(url_for('manage_users'))
        except sqlite3.IntegrityError: flash('该用户名已存在!', 'danger'); conn.rollback()
        except Exception as e: flash(f'添加用户时出错: {e}', 'danger'); conn.rollback()
        finally: conn.close()
        return render_template('add_user.html', username=username, role=role)
    return render_template('add_user.html')

@app.route('/delete_user/<int:user_id>')
@admin_required
def delete_user(user_id):
    conn = get_db_connection(); user_to_delete = conn.execute("SELECT username, role FROM users WHERE id = ?", (user_id,)).fetchone()
    if not user_to_delete: flash('用户不存在!', 'warning')
    elif user_to_delete['username'] == 'admin': flash('不能删除默认的 admin 账户!', 'danger')
    elif user_to_delete['username'] == session.get('username'): flash('不能删除当前登录的用户!', 'danger')
    else:
        try: conn.execute("DELETE FROM users WHERE id = ?", (user_id,)); conn.commit(); log_action('删除用户', f"用户名: {user_to_delete['username']}"); flash(f"用户 '{user_to_delete['username']}' 删除成功!", 'success')
        except Exception as e: flash(f"删除用户时出错: {e}", 'danger'); conn.rollback()
    conn.close()
    return redirect(url_for('manage_users'))

# --- 主题切换路由 ---
@app.route('/set_theme/<theme_name>')
@login_required
def set_theme(theme_name):
    allowed_themes = ['light', 'dark', 'blue', 'green', 'yuan']
    theme_display_names = {
        'light': '简约白',
        'dark': '深色',
        'blue': '拉特蓝',
        'green': '丛雨绿',
        'yuan': '源神'
    }

    if theme_name in allowed_themes:
        session['navbar_theme'] = theme_name # 这个 session 键名用于 layout.html 决定导航栏样式和 main-content 的 data-current-theme
        display_name = theme_display_names.get(theme_name, theme_name.capitalize())
        flash(f"主题已成功切换为: {display_name} ✨", "success")
    else:
        flash("无效的主题名称!", "warning")

    referrer = request.referrer
    if referrer and url_for('login') not in referrer and url_for('logout') not in referrer :
         return redirect(referrer)
    return redirect(url_for('index'))

# --- 主程序入口 ---
if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)