// static/js/background_fade.js
function preloadBackgroundImages(themeImageUrls) {
    Object.values(themeImageUrls).forEach(url => {
        if (url.startsWith('url(') && url !== 'url(\'none\')') {
            const imgUrl = url.match(/url\(['"]?(.*?)['"]?\)/)[1];
            const img = new Image();
            img.src = imgUrl;
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const mainContent = document.getElementById('main-content-wrapper');
    if (!mainContent) {
        console.error("Element with ID 'main-content-wrapper' not found for background fade.");
        return;
    }

    const currentTheme = mainContent.dataset.currentTheme;
    const previousTheme = sessionStorage.getItem('previous_theme_for_bg'); // 更具体的键名

    // 对于外部链接，直接使用URL
    const themeImageUrls = {
        light: "url('/static/images/bg_light.jpg')",
        dark: "url('https://s21.ax1x.com/2025/05/02/pEbG0XD.jpg')",
        blue: "url('/static/images/blue.jpg')",
        /*blue: "url('https://s21.ax1x.com/2025/05/14/pEjuPQU.jpg')",*/
        green: "url('/static/images/congyu.jpg')",
        yuan: "url('https://s21.ax1x.com/2025/05/02/pEbGlXF.jpg')"
    };

    preloadBackgroundImages(themeImageUrls);

    const currentImageUrl = themeImageUrls[currentTheme] || 'none';
    const previousImageUrl = previousTheme ? (themeImageUrls[previousTheme] || 'none') : 'none';

    // 初始化/清理状态
    mainContent.classList.remove('js-bg-before-active', 'js-bg-after-visible', 'js-bg-after-active');
    mainContent.style.setProperty('--after-bg-image', 'none'); // 确保 ::after 初始为空

    if (previousTheme && previousTheme !== currentTheme && previousImageUrl !== 'none' && currentImageUrl !== 'none') {
        //console.log(`Crossfading from ${previousTheme} (${previousImageUrl}) to ${currentTheme} (${currentImageUrl})`);

        mainContent.style.setProperty('--before-bg-image', previousImageUrl); // ::before 是旧图片
        mainContent.style.setProperty('--after-bg-image', currentImageUrl);   // ::after 是新图片

        mainContent.classList.add('js-bg-before-active'); // 旧图片可见
        // js-bg-after-visible 主要作为标记，因为 ::after 默认 opacity:0
        mainContent.classList.add('js-bg-after-visible');

        // 使用双 requestAnimationFrame 确保样式已应用，然后开始过渡
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                mainContent.classList.remove('js-bg-before-active'); // 旧图片 ::before 开始淡出
                mainContent.classList.add('js-bg-after-active');    // 新图片 ::after 开始淡入
            });
        });


        // 过渡完成后，将新图片设置到 ::before，并清理 ::after
        setTimeout(() => {
            mainContent.style.setProperty('--before-bg-image', currentImageUrl);
            mainContent.classList.add('js-bg-before-active'); // ::before 显示新图片
            mainContent.classList.remove('js-bg-after-visible', 'js-bg-after-active'); // 清理 ::after
            mainContent.style.setProperty('--after-bg-image', 'none');
            // console.log('Crossfade complete.');
        }, 450 + 50);

    } else {
        // console.log(`Initial load or no transition for theme: ${currentTheme} (${currentImageUrl})`);
        // 初始加载，或主题未改变，或无上一主题记录
        mainContent.style.setProperty('--before-bg-image', currentImageUrl);
        mainContent.classList.add('js-bg-before-active'); // 直接显示当前主题背景到 ::before
        mainContent.style.setProperty('--after-bg-image', 'none'); // 确保 ::after 没有图像
    }

    // 在页面即将卸载时保存当前主题，用于下次加载判断
    window.addEventListener('beforeunload', () => {
        sessionStorage.setItem('previous_theme_for_bg', currentTheme);
    });

    // 处理主题音乐
    handleThemeMusic(currentTheme);
});


// --- 主题音乐处理器 ---
function handleThemeMusic(theme) {
    const musicPlayer = document.getElementById('theme-music-player');
    if (!musicPlayer) {
        console.error("音乐播放器元素未找到");
        return;
    }

    // 网易云音乐外链URL示例
    const themeMusicUrls = {
        light: "", // 浅色主题不播放音乐或指定一个
        dark: "https://music.163.com/outchain/player?type=2&id=2034454236&auto=1&height=66",
        blue: "https://music.163.com/outchain/player?type=2&id=2699629221&auto=0&height=66", // 示例音乐ID
        green: "https://music.163.com/outchain/player?type=2&id=1303019326&auto=0&height=66", // 示例音乐ID
        yuan: "https://music.163.com/outchain/player?type=2&id=2146888577&auto=1&height=32",  // 示例音乐ID
    };

    const musicUrl = themeMusicUrls[theme] || "";
    const currentSrc = musicPlayer.src;

    // 仅当URL有效且与当前播放的URL不同时才更改播放器源
    // 或者当需要隐藏播放器时
    if (musicUrl) {
        if (currentSrc !== musicUrl) {
            musicPlayer.src = musicUrl;
            musicPlayer.style.display = 'block'; // 显示播放器
        }
    } else {
        // 如果 musicUrl 为空，可以选择停止音乐并隐藏播放器
        // musicPlayer.src = ''; // 这可能会导致不必要的加载或错误，取决于播放器行为
        musicPlayer.style.display = 'block';//显示播放器
    }
}